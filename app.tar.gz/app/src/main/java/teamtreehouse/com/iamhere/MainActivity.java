package teamtreehouse.com.iamhere;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import teamtreehouse.com.iamhere.listener.RecyclerClickListener;
import teamtreehouse.com.iamhere.listener.RecyclerTouchListener;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Context mContext = MainActivity.this;
    private List<teamtreehouse.com.iamhere.PrefData> mPrefDataList;
    private teamtreehouse.com.iamhere.PrefAdapter mPrefAdapter;
    String message,message1;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Intent intent2=getIntent();
        message = intent2.getStringExtra(MapsActivity.EXTRA_MESSAGE);
        message1 = intent2.getStringExtra(MapsActivity.EXTRA_MESSAGE1);
        initViews();
    }

    private void initViews() {

        Button buttonSave = (Button) findViewById(R.id.button_save);
        buttonSave.setOnClickListener(mOnClickListener);

        RecyclerView recyclerViewPrefValues = (RecyclerView) findViewById(R.id.recycler_view_pref_values);
        recyclerViewPrefValues.setLayoutManager(new LinearLayoutManager(mContext));
        mPrefDataList = teamtreehouse.com.iamhere.PrefUtil.getAllValues(mContext);
        mPrefAdapter = new PrefAdapter(mContext, mPrefDataList);
        recyclerViewPrefValues.setAdapter(mPrefAdapter);
        RecyclerTouchListener recyclerTouchListener = new RecyclerTouchListener(mContext, recyclerViewPrefValues, new RecyclerClickListener() {
            @Override
            public void onClick(View view, int position) {
                position = mPrefAdapter.getItemCount() - 1;
              if(position==4){
                PrefData prefData = mPrefDataList.get(0);
                    teamtreehouse.com.iamhere.PrefUtil.removeString(mContext, prefData.key);
                    mPrefDataList.remove(0);
                    mPrefAdapter.notifyItemRemoved(0);

            }}
        });
        recyclerViewPrefValues.addOnItemTouchListener(recyclerTouchListener);
    }

    private void saveValueInPref() {
        String key =message;
        String value = message1;
        PrefUtil.saveString(mContext, key, value);
        PrefData newPrefData = new PrefData(key, value);

            if (mPrefDataList.contains(newPrefData)) {
                int index = mPrefDataList.indexOf(newPrefData);
                mPrefDataList.remove(index);
                mPrefAdapter.notifyItemRemoved(index);
            }
            mPrefDataList.add(newPrefData);
            int position = mPrefAdapter.getItemCount() - 1;
            mPrefAdapter.notifyItemInserted(position);

    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.button_save:
                    saveValueInPref();
                    break;
            }
        }
    };
}
