package teamtreehouse.com.iamhere.listener;

import android.view.View;

public abstract class RecyclerClickListener {

    public void onClick(View view, int position) {
    }

    public void onLongClick(View view, int position) {
    }

}
